drop database if exists db_sebook;

create database db_sebook;

use db_sebook;