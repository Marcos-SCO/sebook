<div id="container">
    <div class="tratamento">

        <H1>Duvidas</H1>

        <div class="itemComentario">
            <figure>
                <img src="../images/icons/Logado.png">
                <figcaption>
                    <p>João Ricardo de Almeida (10/08/2019)</p>
                </figcaption>
            </figure>
            <h4>(Sebo)</h4>
            <section id="balao">
                <div class="balaoContainer">
                    <h5>Problema</h5>
                    <p>
                        Não estou conseguindo inserir livros sem ISBN em meu acervo.
                    </p>

                </div>
                <button class="btn">Responder</button>
            </section>
        </div>

        <div class="itemComentario">
            <figure>
                <img src="../images/icons/Logado.png">
                <figcaption>
                    <p>Mariana Oliveira Lima (10/08/2019)</p>
                </figcaption>
            </figure>
            <h4>(leitor)</h4>

            <section id="balao">
                <div class="balaoContainer">
                    <h5>Sugestão</h5>
                    <p>
                        Tenho dois Sebos para indicar em minha região.
                    </p>

                </div>
                <button class="btn">Responder</button>
            </section>
        </div>

        <div class="itemComentario">
            <figure>
                <img src="../images/icons/Logado.png">
                <figcaption>
                    <p>João Ricardo de Almeida (10/08/2019)</p>
                </figcaption>
            </figure>
            <h4>(Sebo)</h4>
            <section id="balao">
                <div class="balaoContainer">
                    <h5>Duvida</h5>
                    <p>
                        Não estou conseguindo inserir livros sem ISBN em meu acervo.
                    </p>

                </div>
                <button class="btn">Responder</button>
            </section>
        </div>

        </section>
    </div>
</div>