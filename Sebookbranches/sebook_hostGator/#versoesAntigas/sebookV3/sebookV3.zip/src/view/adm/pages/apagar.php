<div class="apagar">
    <section class="containerTable">
        <li>
            <a href="#">
                <table border="1">
                    <tr>
                        <th>Data</th>
                        <th>Nome do usuário</th>
                        <th>Tipo de usuário</th>
                        <th>Mensagem</th>
                        <th>Excluir: S/N</th>
                    </tr>
                    <tr>
                        <td>15/08/2019</td>
                        <td>Luiz Fernando Antunes</td>
                        <td>Leitor</td>
                        <td>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla feugiat mauris vel erat tempus, efficitur bibendum risus laoreet. Aliquam vitae magna molestie, pharetra eros et, vulputate turpis. Cras augue massa, dignissim
                            id odio at, egestas luctus eros.
                        </td>
                    </tr>
                    <tr>
                        <td>16/08/2019</td>
                        <td>Marcelo Dupim Araujo</td>
                        <td>Leitor</td>
                        <td>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla feugiat mauris vel erat tempus, efficitur bibendum risus laoreet. Aliquam vitae magna molestie, pharetra eros et, vulputate turpis. Cras augue massa, dignissim
                            id odio at, egestas luctus eros.
                        </td>
                    </tr>
                </table>
            </a>
        </li>
    </section>
</div>