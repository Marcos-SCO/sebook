<?php
$ajuste = "../../../";
require_once '../../../config/config.php';
?>
<img src="<?= _URLBASE_ ?>public/img/404_morte.jpg">