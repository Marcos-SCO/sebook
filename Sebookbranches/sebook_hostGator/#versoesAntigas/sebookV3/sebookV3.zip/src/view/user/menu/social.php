<div class="Social-Bar">
    <a href="#">
        <img src="<?= _URLBASE_ ?>public/icon/facebook.svg" class="icon icon-facebook" target="">
    </a>
    <a href="#">
        <img src="<?= _URLBASE_ ?>public/icon/instagram.svg" class="icon icon-instagram" target="">
    </a>
    <a href="#">
        <img src="<?= _URLBASE_ ?>public/icon/twitter.svg" class="icon icon-twitter" target="">
    </a>
</div>