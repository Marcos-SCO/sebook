<?php
$title = "FAQ";
?>
<section class="ajuda">
    <div class="container">
        <h1>Contato</h1>
        <p>Deixe aqui sua Duvidas,<br> Opiniões e Sugestões.</p>
        <hr>
        <form action="">
            <label for="">Nome</label>
            <input type="text">

            <label for="">E-mail</label>
            <input type="text">

            <label for="">Texto</label>
            <input class="tex" type="text">

            <button>Enviar</button>
        </form>
    </div>
</section>
