<div class="eventos">
    <div class="container">
        <h2>Eventos</h2>
        <figure>
            <img src="<?= _URLBASE_ ?>public/img/imgBanner/banner2.jpg" alt="">
            <figcaption>Festa do Livro da USP</figcaption>
        </figure>
        <figure>
            <img src="<?= _URLBASE_ ?>public/img/imgBanner/banner3.jpg" alt="">
            <figcaption>Feira Nacional Do Livro</figcaption>
        </figure>
    </div>
</div>