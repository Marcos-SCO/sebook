<div id="container">
    <section class="livros">
        <div class="container">
            <div class="box-descricao-livro">
                <img src="images/img/imgLivros/livroHarry.jpg" alt="">
                <div class="descricaoLivro">
                    <h1>Harry Potter</h1>
                    <p><strong>Autor:</strong>:JK. ROWLING</p>
                    <div class="line-stars">
                        <strong>Avaliação:</strong>
                        <div class="stars">
                            <img src="images/icons/star.png" alt="">
                            <img src="images/icons/star.png" alt="">
                            <img src="images/icons/star.png" alt="">
                            <img class="empty" src="images/icons/star.png" alt="">
                            <img class="empty" src="images/icons/star.png" alt="">
                        </div>
                    </div>
                </div>
            </div>
            <div class="sinopse">
                <p><strong>SINOPSE:</strong></p>
                <p>
                    Harry Potter e a Câmara Secreta é segundo livro da série Harry Potter. O livro se envolve em torno da lenda de uma 
                    câmara secreta localizada na Escola de Magia e Bruxaria de Hogwarts, na qual abriga um 
                    monstro que matará a todos os bruxos que não provém de famílias mágicas. Diversos alunos 
                    aparecem petrificados e Harry Potter, além de ser apontado como o maior suspeito, 
                    tenta desvendar e resolver o mistério junto de seus melhores amigos, Rony Weasley e Hermione Granger.
                </p>
                <div class="comentario">
                    <div class="person">
                        <img src="images/icons/user-comments.png" alt="">
                        <div class="descricao-person">
                            <strong>paulo_10</strong>
                            <div class="stars">
                                <img src="images/icons/star.png" alt="">
                                <img src="images/icons/star.png" alt="">
                                <img src="images/icons/star.png" alt="">
                                <img class="empty" src="images/icons/star.png" alt="">
                                <img class="empty" src="images/icons/star.png" alt="">
                            </div>
                        </div>
                    </div>   
                    <p>O filme é muito bom mais o livro é esplêndido!!!!</p>                   
                </div>
                <div class="comentario">
                    <div class="person">
                        <img src="images/icons/user-comments.png" alt="">
                        <div class="descricao-person">
                            <strong>fernada_silva</strong>
                            <div class="stars">
                                <img src="images/icons/star.png" alt="">
                                <img src="images/icons/star.png" alt="">
                                <img src="images/icons/star.png" alt="">
                                <img class="empty" src="images/icons/star.png" alt="">
                                <img class="empty" src="images/icons/star.png" alt="">
                            </div>
                        </div>
                    </div>   
                    <p>Melhor franquia da vida</p>                   
                </div>
                
            </div>
            
        </div>
    </div>
</div>
</section>
</div>